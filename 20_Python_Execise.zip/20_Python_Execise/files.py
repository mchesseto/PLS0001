
#!/usr/bin/python3
# files.py by Bill Weinman [http://bw.org/]
# This is an exercise file from Python 3 Essential Training on lynda.com
# Copyright 2010 The BearHeart Group, LLC

import pandas as pd
import csv
import time


#Read python file
df = pd.read_csv (r'D:\PYHON\20_Python_Execise\Input_files\input.csv')
print (df)

# Total Amount
Amount = df['Amount'].sum()
print('The total Amount is:',Amount)

# Total Count of products
Amount = df['Product'].count()
print('The total count of products is:',Amount)


# Total count of Loans grouped by product
start = time.time()
csvData= df.groupby('Product')['Product'].count()
csvData.to_csv(r'D:\PYHON\20_Python_Execise\Output_files\output-Count_of_Loans_grouped_by_product.csv',index = True, header=True)
print(csvData)
end = time.time()
print('Execution Time:',end - start)

#Total Amount grouped by product
start = time.time()
csvData= df.groupby('Product')['Amount'].sum()
csvData.to_csv(r'D:\PYHON\20_Python_Execise\Output_files\output-Total_Amount_grouped_by_product.csv',index = True, header=True)
print(csvData)
end = time.time()
print('Execution Time:',end - start)

